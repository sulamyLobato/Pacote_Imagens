"""
este é um pacote de processamento de imagens que fornece funções e classes
para aplicar filtros, redimensionar e cortar imagens.
"""


__version__ = '0.1.0'
__author__ = 'Sulamy'
__description__ = 'Um pacote para processamento de imagens.'